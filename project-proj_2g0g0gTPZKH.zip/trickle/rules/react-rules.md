When writing React components:
- Always use `className` instead of `class` for CSS classes in JSX.
- Always use `htmlFor` instead of `for` for label inputs.
- Ensure all tags are properly closed.