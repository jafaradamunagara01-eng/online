# JR Nagara Online Test Portal

This project is a comprehensive CBT (Computer Based Test) solution integrated with the Trickle database.

## Key Features
- **Student Portal**: Face verification, real-time exam interface, and secure monitoring.
- **Admin Portal**: Dashboard for managing tests, students, and live monitoring of candidates.
- **Results**: Automated grading and result checking with printable slips.
- **Registration**: Self-service registration and manual admin entry.

## Stability Notes
- The application uses a custom `utils/storage.js` wrapper to handle database interactions.
- Retry logic with exponential backoff is implemented to handle "Failed to fetch" network errors.
- Session IDs are cached in `sessionStorage` to minimize heavy database queries.
- Monitoring updates are throttled to 5-second intervals to prevent rate limiting.

## File Structure
- `index.html`: Landing page.
- `admin.html`: Admin dashboard entry.
- `student.html`: Exam interface entry.
- `register.html`: Registration entry.
- `result.html`: Result checking entry.
- `utils/storage.js`: Centralized DB logic.