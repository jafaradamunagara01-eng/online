// Trickle Database Wrapper
// Migrating from LocalStorage to Async Database Calls

const DB_TABLES = {
    TESTS: 'test',
    STUDENTS: 'student',
    RESULTS: 'result',
    SETTINGS: 'system_settings',
    MONITORING: 'monitoring_session'
};

// Cache for the current student's session ID to avoid repeated lookups
let _currentSessionId = null;

const Storage = {
    // Helper for retry logic - Robust Exponential Backoff
    retryOperation: async (operation, maxRetries = 3) => {
        let lastError;
        for (let i = 0; i < maxRetries; i++) {
            try {
                return await operation();
            } catch (err) {
                lastError = err;
                console.warn(`Attempt ${i + 1} failed for DB op:`, err);
                if (i < maxRetries - 1) {
                    // 500ms, 1000ms, 2000ms
                    const delay = 500 * Math.pow(2, i); 
                    await new Promise(resolve => setTimeout(resolve, delay));
                }
            }
        }
        throw lastError;
    },

    // --- GENERIC UTILS ---
    // Updated to use pagination for better stability
    getAll: async (table) => {
        let allItems = [];
        let nextPageToken = undefined;
        try {
            do {
                const response = await Storage.retryOperation(() => 
                    // Fetch in batches of 50 to avoid timeouts/large payloads
                    trickleListObjects(table, 50, true, nextPageToken)
                );
                
                if (response && response.items) {
                    allItems = [...allItems, ...response.items];
                    nextPageToken = response.nextPageToken;
                } else {
                    nextPageToken = null;
                }
            } while (nextPageToken);

            return allItems.map(item => ({
                ...item.objectData,
                _id: item.objectId
            }));
        } catch (e) {
            console.error(`DB Error: Failed to fetch ${table}`, e);
            // Return empty array to prevent app crash, but log error
            return [];
        }
    },

    create: async (table, data) => {
        try {
            const response = await Storage.retryOperation(() => 
                trickleCreateObject(table, data)
            );
            return { ...response.objectData, _id: response.objectId };
        } catch (e) {
            console.error(`DB Error: Failed to create in ${table}`, e);
            throw e;
        }
    },

    update: async (table, id, data) => {
        try {
            await Storage.retryOperation(() => 
                trickleUpdateObject(table, id, data)
            );
        } catch (e) {
            console.error(`DB Error: Failed to update ${table} ${id}`, e);
        }
    },

    delete: async (table, id) => {
        try {
            await Storage.retryOperation(() => 
                trickleDeleteObject(table, id)
            );
        } catch (e) {
            console.error(`DB Error: Failed to delete from ${table}`, e);
        }
    },

    // --- TESTS ---
    getTests: async () => Storage.getAll(DB_TABLES.TESTS),
    saveTest: async (test) => {
        const tests = await Storage.getTests();
        const existing = tests.find(t => t.id === test.id);
        
        if (existing) {
            await Storage.update(DB_TABLES.TESTS, existing._id, test);
        } else {
            await Storage.create(DB_TABLES.TESTS, test);
        }
    },
    deleteTest: async (testId) => {
        const tests = await Storage.getTests();
        const target = tests.find(t => t.id === testId);
        if (target) await Storage.delete(DB_TABLES.TESTS, target._id);
    },

    // --- STUDENTS ---
    getStudents: async () => Storage.getAll(DB_TABLES.STUDENTS),
    saveStudent: async (student) => {
        return await Storage.create(DB_TABLES.STUDENTS, student);
    },
    updateStudent: async (regNumber, updates) => {
        const students = await Storage.getStudents();
        const student = students.find(s => s.regNumber === regNumber);
        if (student) {
            await Storage.update(DB_TABLES.STUDENTS, student._id, updates);
        }
    },
    deleteStudent: async (regNumber) => {
        const students = await Storage.getStudents();
        const target = students.find(s => s.regNumber === regNumber);
        if (target) await Storage.delete(DB_TABLES.STUDENTS, target._id);
    },

    // --- RESULTS ---
    getResults: async () => Storage.getAll(DB_TABLES.RESULTS),
    saveResult: async (result) => {
        await Storage.create(DB_TABLES.RESULTS, result);
    },

    // --- SETTINGS ---
    getSettings: async () => {
        const items = await Storage.getAll(DB_TABLES.SETTINGS);
        const settings = {};
        items.forEach(item => {
            try {
                settings[item.key] = JSON.parse(item.value);
            } catch {
                settings[item.key] = item.value;
            }
        });
        return settings;
    },
    
    setSetting: async (key, value) => {
        const items = await Storage.getAll(DB_TABLES.SETTINGS);
        const existing = items.find(i => i.key === key);
        const valStr = JSON.stringify(value);
        
        if (existing) {
            await Storage.update(DB_TABLES.SETTINGS, existing._id, { key, value: valStr });
        } else {
            await Storage.create(DB_TABLES.SETTINGS, { key, value: valStr });
        }
    },

    // --- LIVE MONITORING (OPTIMIZED) ---
    // Uses separate table 'monitoring_session' to avoid payload size issues with 'system_settings'
    
    updateStudentStatus: async (studentId, statusData) => {
        try {
            // If we don't have a cached session ID, try to find it or create it
            if (!_currentSessionId) {
                // We list all to find ours. 
                const allSessions = await Storage.getAll(DB_TABLES.MONITORING);
                const mySession = allSessions.find(s => s.studentId === studentId);
                
                if (mySession) {
                    _currentSessionId = mySession._id;
                } else {
                    // Create new session
                    const newSession = await Storage.create(DB_TABLES.MONITORING, {
                        studentId,
                        ...statusData,
                        lastSeen: new Date().toISOString()
                    });
                    _currentSessionId = newSession._id;
                    return; // Created, done for this cycle
                }
            }
            
            // Update using cached ID
            if (_currentSessionId) {
                // DO NOT retry rigorously for status updates to keep UI snappy; if one fails, next one will catch up
                trickleUpdateObject(DB_TABLES.MONITORING, _currentSessionId, {
                    studentId, // maintain relation
                    ...statusData,
                    lastSeen: new Date().toISOString()
                }).catch(e => {
                    console.warn("Monitor update skipped:", e);
                    _currentSessionId = null; // Reset cache on error to force re-fetch next time
                });
            }
        } catch (e) {
             console.error("Monitor update failed", e);
             _currentSessionId = null;
        }
    },

    getLiveSessions: async () => {
        try {
            // Fetch all active sessions from the dedicated table
            const items = await Storage.getAll(DB_TABLES.MONITORING);
            
            // Convert to object keyed by studentId for compatibility with Admin UI
            const sessions = {};
            items.forEach(item => {
                sessions[item.studentId] = item;
            });
            return sessions;
        } catch (e) {
            console.error("Failed to get live sessions", e);
            return {};
        }
    },

    // --- MESSAGES ---
    sendMessage: async (studentId, message) => {
        const settings = await Storage.getSettings();
        const msgs = settings.messages || [];
        msgs.push({
            id: Date.now(),
            studentId,
            text: message,
            read: false,
            timestamp: new Date().toISOString()
        });
        await Storage.setSetting('messages', msgs);
    },
    getMessages: async (studentId) => {
        const settings = await Storage.getSettings();
        const msgs = settings.messages || [];
        return msgs.filter(m => m.studentId === studentId);
    },
    markMessageRead: async (msgId) => {
        const settings = await Storage.getSettings();
        const msgs = settings.messages || [];
        const index = msgs.findIndex(m => m.id === msgId);
        if(index >= 0) {
            msgs[index].read = true;
            await Storage.setSetting('messages', msgs);
        }
    }
};

window.JRStorage = Storage;